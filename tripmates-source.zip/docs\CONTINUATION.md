# Continuing TripMates (Antigravity or any coding assistant)

Open this folder, run `npm install && npm test` (expect 30 passing). Put your original TripMates brief in `docs/SPEC.md`.
Never change `backend/src/finance` without keeping its tests green. All balance and split logic must be called from
there, never reimplemented in routes or UI.

## Remaining work, in order
1. Backend (`backend/src`): Express + TypeScript, `better-sqlite3` or Drizzle over the schema in `database/`, a
   migration runner (never silently overwrite a DB), zod validation, transactions for expense + items + allocations.
2. Auth: argon2/bcrypt hashing, secure sessions, first-Super-Admin setup command (no hardcoded passwords),
   server-side role and family-isolation checks on every route, private completed-trip restriction.
3. API: families, persons, trips, invitations, attendance (+ attendance_log), expenses (preview + save through the
   finance module), repayments (validateRepayment before insert), settlements, reports, audit log.
4. Frontend (`frontend/`): React + Vite + TypeScript, mobile-first. Priority screen: the itemized bill editor
   (add item → pick who ordered → live per-person amounts → warnings). Then expense wizard with select all /
   deselect / by family / exclude members, settlement screen, dashboard.
5. i18n English + Telugu (dictionary + persisted language), Indian currency formatting (`formatINR`).
6. Nature design with bundled, licensed images (document sources); optional Leaflet/OSM maps last. No offline maps, no uploads.
7. Dev-only seed command; backup docs; integration tests for auth and data isolation; generate lockfile.

## Ready-to-paste prompt
> This repository contains a tested financial engine (`backend/src/finance`) and SQLite schema (`database/`).
> Read README.md, docs/FINANCIAL_RULES.md and docs/SPEC.md. Build the remaining items in docs/CONTINUATION.md in order,
> reusing the finance module for every calculation, keeping `npm test` green, adding tests for each new endpoint
> (especially authorization and family data isolation), and do not claim anything works until you have run it.
